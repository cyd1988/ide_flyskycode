# Change Log

## 0.1.2 (2019-03-16)
- default mode on load

## 0.1.1 (2019-01-20)
- fix broken trigger

## 0.1.0 (2019-01-19)
- added sidebar

## 0.0.8 (2018-08-14)
- added `defaultMode` option

## 0.0.7 (2017-09-18)
- select word at cursor if nothing selected

## 0.0.6 (2017-09-13)
- make colors configurable
- option to display box or background style highlight
- defer activation to on commands
- rename commands from generic 'extension' to more explicit 'highlightwords', **this will require an update to any keyboard shortcuts you may have configured**

## 0.0.5 (2017-04-09)
- added whole word and ignore case
- only update current document on content change
- apply highlights on peek when initially inactive

## 0.0.4 (2017-01-14)
- remove annoyance

## 0.0.3 (2017-01-14)
- Better light theme support

## 0.0.2 (2017-01-02)
- Package update

## 0.0.1 (2017-01-02)
- Initial release
